@extends('template.' . $template)

@section('content')
    @include('asset.team-catalog')
@endsection
