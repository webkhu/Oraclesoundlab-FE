@extends('template.' . $template)

@section('content')
    @include('asset.events-catalog')
@endsection
