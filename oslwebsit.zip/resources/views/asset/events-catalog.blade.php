<div class="mb-4 row align-items-center">
    <div class="col">
        <h1>{{ $title }}</h1>
    </div>
    @if ($active === 'index' || $active === 'home')
        <div class="col text-end add-menu"><a href="{{ url('/events') }}">View more <i
                    class="bi bi-caret-right-fill"></i></a>
        </div>
    @endif
</div>
@if (!empty(@$events))
    @if ($active != 'index' && $active != 'home' && $active != 'search')
        <div class="mb-3">{{ $events->links('pagination::webkhu') }}</div>
    @endif
    <div class="row g-4 cols-1 row-cols-sm-2 row-cols-md-4 row-cols-lg-4 row-cols-xl-6 row-cols-xxl-8">
        @foreach ($events as $event)
            @php
                list($d, $m, $Y) = explode('/', $event->date);
                if (strtotime($Y . '/' . $m . '/' . $d) > time()) {
                    $status = '';
                } else {
                    $status = 'Past Event';
                }
            @endphp
            <div id="imgcontainer" class="col-xl-3" onClick="location.href='{{ url('/events/' . $event->slug) }}'">
                <div class="imgborder">
                    <div class="imggalbox">
                        <div class="bg-img-wrapper mb-4">
                            <div style="background-image:url({{ url(env('API_LINK') . '/event/admin/' . $event->image) }})"
                                class="bg-img d-flex">
                                @if ($status)
                                    <div class="img-status align-self-center">{{ $status }}</div>
                                @endif
                            </div>
                        </div>
                        <div class="img-setup">
                            <div class="bold text-glow mb-2">{{ $event->title }}</div>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
@endif
