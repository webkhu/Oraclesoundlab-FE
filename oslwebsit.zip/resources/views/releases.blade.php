@extends('template.' . $template)

@section('content')
    @include('asset.releases-catalog')
@endsection
