@extends('template.' . $template)

@section('content')
    @include('asset.artist-catalog')
@endsection
