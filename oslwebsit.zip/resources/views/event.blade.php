@extends('template.' . $template)

@section('content')
    @if ($datas === '')
        No data Founded
    @else
        <div class="mb-5">
            <h1>{{ $datas->title }}</h1>
        </div>
        <div class="artist-detail mb-5">
            <div class="artist-img album-img">
                <img src="{{ url(env('API_LINK') . '/event/admin/' . $datas->image) }}" alt="{{ $datas->title }}"
                    width="100%">
            </div>
            <div id="details" class="artist-desc">
                @if ($status)
            <h2 class="mb-4" style="color:orangered">{{ '# ' . $status }}</h2>
            @endif
                <h4 class="mb-3"><strong>Perform date:</strong></h4>
                <div class="mb-4">{{ $date }}</div>
                <h4 class="mb-3"><strong>Event location:</strong></h4>
                <div class="mb-2">{{ $datas->location }}</div>
                <div class="mb-4 text-sm"><a href="javascript:popupMap('{{ $datas->map }}')">Location map</a></div>
                <div>{!! $datas->description !!}</div>
            </div>
        </div>

        <div class="d-flex mt-4 justify-content-start">
            <button class="btn btn-off btn-carousel" type="submit" style="border-radius: 5px;"
                onclick="window.history.back()">Back to {{ $active }}</button>
        </div>
    @endif
@include('asset.mapPopup')
@include('asset.modalPopup')
@endsection
