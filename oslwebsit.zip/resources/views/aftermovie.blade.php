@extends('template.' . $template)

@section('content')
    @include('asset.streaming-catalog')
@endsection
