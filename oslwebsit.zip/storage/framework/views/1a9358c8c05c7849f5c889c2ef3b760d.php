<?php
    if (is_array($datas)) {
        $datas = $datas[0];
    }
?>


<?php if($active != 'index' && $active != 'home'): ?>
    <?php if(@$setToPlay): ?>
        <div style="width: 90%; margin: auto;">
            <div class="setPlay"><?php echo $setToPlay->player->embedHtml; ?></div>
            <div class="playerArea mt-3 mb-5 img-setup text-center"><?php echo e($setToPlay->snippet->title); ?></div>
        </div>
    <?php endif; ?>
<?php endif; ?>
<div class="mb-4 row align-items-center">
    <div class="col">
        <h1><?php echo e($title); ?></h1>
    </div>
    <?php if($active === 'index' || $active === 'home'): ?>
        <div class="col text-end add-menu"><a href="<?php echo e(url('/streaming')); ?>">View more <i
                    class="bi bi-caret-right-fill"></i></a>
        </div>
    <?php endif; ?>
</div>
<?php if(!empty(@$datas)): ?>
    <?php if($active != 'index' && $active != 'home'): ?>
        <?php
            $get_page = $active;
        ?>
        <div class="mb-3"><?php echo e($datas->links('pagination::youtube')); ?></div>
    <?php endif; ?>

    <div class="row g-4 cols-1 row-cols-sm-2 row-cols-md-4 row-cols-lg-4 row-cols-xl-6 row-cols-xxl-8">
        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                if (request()->get('page')) {
                    $setURL = url('/' . $get_page) . '?page=' . request()->get('page') . '&setPage=' . request()->get('setPage') . '&';
                } else {
                    $setURL = url('/' . $get_page) . '?';
                }
            ?>
            <div id="imgcontainer" class="col-xl-3"
                onClick="location.href='<?php echo e($setURL . 'id=' . $data->snippet->resourceId->videoId); ?>'">
                <div class="imgborder">
                    <div class="imggalbox text-glow">
                        <div class="bg-img-wrapper mb-3">
                            <div style="background-image:url(<?php echo e($data->snippet->thumbnails->medium->url); ?>);"
                                class="bg-img">
                            </div>
                        </div>
                        <div class="img-setup"><?php echo e($data->snippet->title); ?></div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php /**PATH F:\Web-Project\oraclesoundlab\oslwebsite\resources\views/asset/streaming-catalog.blade.php ENDPATH**/ ?>