<section id="Header">
    <div class="header" role="navigation">
        <div class="header-nav">
            
            <div class="header-box header-box-sm">
                <img class="header-logo" src="<?php echo e($url); ?>/template/oraclesoundlab_logo.gif">
            </div>
            <div class="submit"></div>
            <div class="header-box header-box-bg">
                
                <?php $__currentLoopData = collect($pages)->where('position', 'Header'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        if ($active === $page->name) {
                            $cl = 'active';
                        } else {
                            $cl = '';
                        }
                    ?>
                    <div class="me-4 <?php echo e($cl); ?>">
                        <?php if($page->type === 'Add'): ?>
                            <a href="<?php echo e($url); ?>/page/<?php echo e($page->name); ?>">
                            <?php else: ?>
                                <a href="<?php echo e($url); ?>/<?php echo e($page->name); ?>">
                        <?php endif; ?>
                        <?php echo e($page->link); ?>

                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                <form action="<?php echo e(url('search')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo method_field('post'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="input-group input-group-sm search">
                        <input type="text" id="search" name="search" class="form-control" placeholder="Search" aria-label="Search"
                            aria-describedby="button-addon2" autocomplete="off">
                        <button class="btn btn-on" type="submit"><i class="bi bi-search"></i></button>
                    </div>
                </form>
            </div>
            <form class="header-box header-search-sm" id="search-sm" action="<?php echo e(url('search')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo method_field('post'); ?>
                <?php echo csrf_field(); ?>
                <div class="input-group input-group-sm search-sm">
                    <input type="text" name="search" class="form-control" placeholder="Search" aria-label="Search"
                        aria-describedby="button-addon2">
                    <button class="btn btn-on" type="submit"><i class="bi bi-search"></i></button>
                </div>
                <div class="ms-2">
                    <button class="btn btn-sm btn-outline-secondary" type="button" onclick="openSearch()"><i
                            class="bi bi-x-lg"></i></button>
                </div>
            </form>
            
            <div class="header-box header-box-sm">
                <?php $__currentLoopData = collect($pages)->where('position', 'Header'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        if ($active === $page->name) {
                            $cl = 'active';
                        } else {
                            $cl = '';
                        }
                    ?>
                    <div class="me-2">
                        <button class="btn btn-sm btn-on <?php echo e($cl); ?>" type="button"
                            onclick="location.href='<?php echo e($url); ?>/<?php echo e(Str::lower($page->name)); ?>'"><i
                                class="<?php echo e($page->icon); ?>"></i></button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <div class="me-3">
                    <button class="btn btn-sm btn-on" type="button" onclick="openSearch()"><i
                            class="bi bi-search"></i></button>
                </div>
                <!-- Colapse Menu -->
                <div class="close-toggler" onclick="myFunction(this)" id="close-toggle">
                    <div class="bar1"></div>
                    <div class="bar2"></div>
                    <div class="bar3"></div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH F:\Web-Project\oraclesoundlab\oslwebsite\resources\views/template/header.blade.php ENDPATH**/ ?>