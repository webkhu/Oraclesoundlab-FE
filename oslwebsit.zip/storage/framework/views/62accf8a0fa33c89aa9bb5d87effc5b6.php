<div class="mb-4 row align-items-center">
    <div class="col">
        <h1><?php echo e($title); ?></h1>
    </div>
    <?php if($active === 'index' || $active === 'home'): ?>
        <div class="col text-end add-menu"><a href="<?php echo e(url('/teams')); ?>">View more <i
                    class="bi bi-caret-right-fill"></i></a>
        </div>
    <?php endif; ?>
</div>
<?php if(!empty(@$teams)): ?>
    <div class="row g-4 cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-3 row-cols-xxl-4">
        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="imgcontainer" class="col"
                onClick="popup('<?php echo e(url(env('API_LINK') . '/teams/web/' . $team->image)); ?>','<strong><?php echo e($team->name); ?></strong><br><?php echo e($team->title); ?>');">
                <div class="imgborder">
                    <div class="imggalbox">
                        <div class="bg-img-wrapper mb-4">
                            <div style="background-image:url(<?php echo e(url(env('API_LINK') . '/teams/admin/' . $team->image)); ?>);"
                                class="bg-img">
                            </div>
                        </div>
                        <div class="bold text-glow"><?php echo e($team->name); ?></div>
                        <div class="mb-2"><i><?php echo e($team->title); ?></i></div>
                        <div class="text-justify"><?php echo e($team->short_desc); ?></div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('asset.modalPopup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php endif; ?>
<?php /**PATH F:\Web-Project\oraclesoundlab\oslwebsite\resources\views/asset/team-catalog.blade.php ENDPATH**/ ?>