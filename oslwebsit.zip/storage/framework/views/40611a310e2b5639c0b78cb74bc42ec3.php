

<?php $__env->startSection('content'); ?>
    <?php if($datas === ''): ?>
        No data Founded
    <?php else: ?>
        <div class="mb-5">
            <h1><?php echo e($datas->name); ?></h1>
            <h2><?php echo e($datas->title); ?></h2>
        </div>
        <div class="artist-detail mb-5">
            <div class="artist-img">
                <img src="<?php echo e(url(env('API_LINK') . '/artists/admin/' . $datas->image)); ?>" alt="<?php echo e($datas->name); ?>"
                    width="100%">
            </div>
            <div class="artist-desc"><?php echo $datas->description; ?></div>
        </div>
        <?php if(!empty($items)): ?>
            <h3 class="mb-3">Photo Gallery</h3>
            <div class="row cols-1 row-cols-sm-2 row-cols-md-4 row-cols-lg-4">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="imgcontainer" class="col-lg-3 mb-4">
                        <div class="imgborder">
                            <div class="imggalbox">
                                <div class="bg-img-wrapper mb-4">
                                    <div style="background-image:url(<?php echo e(url(env('API_LINK') . '/artists/gallery/' . $item->image)); ?>)"
                                        class="bg-img"
                                        onClick="popup('<?php echo e(url(env('API_LINK') . '/artists/gallery/' . $item->image)); ?>','<?php echo e($item->title); ?>');">
                                    </div>
                                </div>
                                <div class="img-setup">
                                    <div><?php echo e($item->title); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('asset.modalPopup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php endif; ?>
        <div class="d-flex mt-4 justify-content-start">
            <button class="btn btn-off btn-carousel" type="submit" style="border-radius: 5px;"
                onclick="window.history.back()">Back to <?php echo e($active); ?></button>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.' . $template, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web-Project\oraclesoundlab\oslwebsite\resources\views/artist.blade.php ENDPATH**/ ?>