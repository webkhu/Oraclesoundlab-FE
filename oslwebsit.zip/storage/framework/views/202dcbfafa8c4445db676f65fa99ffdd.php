<?php if($paginator->hasPages()): ?>
    <nav class="d-flex justify-items-center justify-content-between">
        <div class="d-flex justify-content-between flex-fill d-sm-none">
            <ul class="paginate">
                
                <?php if($paginator->onFirstPage()): ?>
                    <li aria-disabled="true">
                        <span class="btn btn-on active"><i class=" bi bi-caret-left"></i></span>
                    </li>
                <?php else: ?>
                    <li>
                        <a class="btn btn-on"
                            href="<?php echo e($paginator->previousPageUrl()); ?>"
                            rel="prev"><i class=" bi bi-caret-left"></i></a>
                    </li>
                <?php endif; ?>

                
                <?php if($paginator->hasMorePages()): ?>
                    <li>
                        <a class="btn btn-on"
                            href="<?php echo e($paginator->nextPageUrl()); ?>"
                            rel="next"><i class=" bi bi-caret-right"></i></a>
                    </li>
                <?php else: ?>
                    <li aria-disabled="true">
                        <span class="btn btn-on active"><i class=" bi bi-caret-right"></i></span>
                    </li>
                <?php endif; ?>
            </ul>
        </div>

        <div class="d-none flex-sm-fill d-sm-flex align-items-sm-center justify-content-sm-between">
            <div>
                <p class="small">
                    <span><?php echo e($paginator->firstItem()); ?></span>
                    <?php echo __('to'); ?>

                    <span><?php echo e($paginator->lastItem()); ?></span>
                    <?php echo __('from'); ?>

                    <span><?php echo e($paginator->total()); ?></span>
                    <?php echo __('results'); ?>

                </p>
            </div>

            <div>
                <ul class="paginate">
                    
                    <?php if($paginator->onFirstPage()): ?>
                        <li class="me-3" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                            <span class="btn btn-on active" aria-hidden="true"><i
                                    class=" bi bi-caret-left-fill"></i></span>
                        </li>
                    <?php else: ?>
                        <li class="me-3">
                            <a class="btn btn-on"
                                href="<?php echo e($paginator->previousPageUrl()); ?>"
                                rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>"><i
                                    class=" bi bi-caret-left-fill"></i></a>
                        </li>
                    <?php endif; ?>

                    
                    <?php if($paginator->hasMorePages()): ?>
                        <li>
                            <a class="btn btn-on"
                                href="<?php echo e($paginator->nextPageUrl()); ?>"
                                rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>"><i
                                    class=" bi bi-caret-right-fill"></i></a>
                        </li>
                    <?php else: ?>
                        <li aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                            <span class="btn btn-on active" aria-hidden="true"><i
                                    class=" bi bi-caret-right-fill"></i></span>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
<?php endif; ?>
<?php /**PATH F:\Web-Project\oraclesoundlab\oslwebsite\resources\views/vendor/pagination/webkhu.blade.php ENDPATH**/ ?>