<section id="Sidebar">
    <div class="sidebar" id="sidebar">
        
        <div class="logo"><img id="logo" src="<?php echo e($url); ?>/template/oraclesoundlab_logo.gif"></div>
        
        <div class="menu-area">
            <ul class="menu">
                <?php $__currentLoopData = collect($pages)->where('position', 'Sidebar'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        if ($active === $page->name) {
                            $cl = 'active';
                        } else {
                            $cl = '';
                        }
                    ?>
                    <?php if(collect($subpages)->flatten()->where('parent_id', $page->id)->last()): ?>
                        <li class="has-sub <?php echo e($cl); ?>">
                            <a href="javascript:;">
                                <?php if(isset($page->icon)): ?>
                                    <i class="<?php echo e($page->icon); ?>"></i>
                                <?php endif; ?> <?php echo e($page->link); ?><div class="float-end"><i
                                        class="bi bi-caret-down-fill" style="font-size: 0.7em"></i></div>
                            </a>
                            <ul class="submenu">
                                <?php $__currentLoopData = $subpages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subpage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e($url); ?>/<?php echo e(Str::lower($subpage->name)); ?>"><i
                                                class="bi bi-dash"></i><?php echo e($subpage->link); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class=<?php echo e($cl); ?>>
                            <?php if($page->type === 'Add'): ?>
                                <a href="<?php echo e($url); ?>/page/<?php echo e(Str::lower($page->name)); ?>">
                                <?php else: ?>
                                    <a href="<?php echo e($url); ?>/<?php echo e(Str::lower($page->name)); ?>">
                            <?php endif; ?>
                            <?php if(isset($page->icon)): ?>
                                <i class="<?php echo e($page->icon); ?>"></i>
                            <?php endif; ?>
                            <?php echo e($page->link); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php
                if ($active === 'submission') {
                    $cl = 'active';
                } else {
                    $cl = '';
                }
            ?>
            <div class="menu-gold <?php echo e($cl); ?> bold mt-5 d-flex justify-content-between" id="music-submit"
                onclick="location.href='<?php echo e($url); ?>/submission'">
                <div class="col justify-content-start"><i class="bi bi-music-note-beamed"></i>Send Demo</div><i
                    class="col-2 bi bi-caret-right-fill ms-5"></i>
            </div>
        </div>
    </div>
</section>
<?php /**PATH F:\Web-Project\oraclesoundlab\oslwebsite\resources\views/template/sidebar.blade.php ENDPATH**/ ?>