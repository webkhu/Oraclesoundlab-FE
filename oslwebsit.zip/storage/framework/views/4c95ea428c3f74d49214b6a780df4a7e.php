<div class="mb-4 row align-items-center">
    <div class="col">
        <h1><?php echo e($title); ?></h1>
    </div>
    <?php if(@$active === 'index' || $active === 'home'): ?>
        <div class="col text-end add-menu"><a href="<?php echo e(url('/article')); ?>">View more <i
                    class="bi bi-caret-right-fill"></i></a>
        </div>
    <?php endif; ?>
</div>
<?php if(!empty(@$article)): ?>
    <div class="row g-4 cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-3 row-cols-xxl-3">
        <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="imgcontainer" class="col" onClick="location.href='<?php echo e(url('/article/' . $content->slug)); ?>'">
                <div class="article-area">
                    <div class="bold text-glow mb-3"><?php echo e($content->title); ?></div>
                    <div class="text-justify"><?php echo e($content->short_desc); ?></div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php /**PATH F:\Web-Project\oraclesoundlab\oslwebsite\resources\views/asset/article-catalog.blade.php ENDPATH**/ ?>