<div class="mb-4 row align-items-center">
    <div class="col">
        <h1><?php echo e($title); ?></h1>
    </div>
    <?php if($active === 'index' || $active === 'home'): ?>
        <div class="col text-end add-menu"><a href="<?php echo e(url('/releases')); ?>">View more <i
                    class="bi bi-caret-right-fill"></i></a>
        </div>
    <?php endif; ?>
</div>
<?php if(!empty(@$releases)): ?>
<?php if($active != 'index' && $active != 'home'): ?>
        <div class="mb-3"><?php echo e($albumIds->links('pagination::webkhu')); ?></div>
    <?php endif; ?>
    <div class="row g-4 cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-3 row-cols-xxl-4">
        <?php $__currentLoopData = $releases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $release): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="imgcontainer" class="col"
                onClick="location.href='<?php echo e(url('/releases/' . base64_encode($release->id))); ?>'">
                <div class="imgborder">
                    <div class="imggalbox">
                        <div class="bg-img-wrapper mb-4">
                            <div style="background-image:url(<?php echo e($release->images[1]->url); ?>);" class="bg-img">
                            </div>
                        </div>
                        <div class="bold text-glow"><?php echo e($release->name); ?></div>
                        <div><i><?php echo e($release->artists[0]->name); ?></i></div>
                        
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php /**PATH F:\Web-Project\oraclesoundlab\oslwebsite\resources\views/asset/releases-catalog.blade.php ENDPATH**/ ?>