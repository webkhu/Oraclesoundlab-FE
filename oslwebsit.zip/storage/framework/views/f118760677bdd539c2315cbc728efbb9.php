

<?php $__env->startSection('content'); ?>
    <?php if($albumDetail === ''): ?>
        No data Founded
    <?php else: ?>
        <h1 class="text-start"><?php echo e($albumDetail->name); ?></h1>
        <h2 class="text-start mb-5"><?php echo e($albumDetail->artists[0]->name); ?> (<?php echo e($albumDetail->release_date); ?>)</h2>
        <div class="row">
            <div class="col artist-img album-img">
                <img src="<?php echo e($albumDetail->images[0]->url); ?>" alt="<?php echo e($albumDetail->name); ?>" width="100%" class="mb-3">
            </div>
            <div class="col">
                <table class="w-100">
                    <thead>
                        <tr style="height: 50px">
                            <th class="col pe-3 text-center">#</th>
                            <th class="col-10 pe-2">Title</th>
                            <th class="col pe-2 text-center"><i class="bi bi-clock" aria-label="duration"></i></th>
                            <th class="col pe-2 text-center">Demo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $albumDetail->tracks->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center pe-3" height="45"><?php echo e($loop->iteration); ?>.</td>
                                <td class="pe-2"><?php echo e($track->name); ?></td>
                                <td class="text-center pe-2">
                                    <?php
                                        $input = $track->duration_ms;

                                        $seconds = $input % 60;
                                        $input = floor($input / 60);

                                        $minutes = $input % 60;
                                        $input = floor($input / 60);

                                    ?>
                                    <?php echo e(sprintf('%02d:%02d', $minutes, $seconds)); ?>

                                </td>
                                <td class="text-center pe-2 fs-5">
                                    <div id="<?php echo e('button' . $loop->iteration); ?>" onclick="audioPlay(<?php echo e($loop->iteration); ?>)"
                                        style="cursor: pointer"><i class="bi bi-play-circle-fill"></i></div>
                                    <audio id="<?php echo e($loop->iteration); ?>" src="<?php echo e($track->preview_url); ?>"
                                        type="audio/mp3"></audio>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
        <div class="d-flex mt-4 justify-content-between">
            <button class="btn btn-off btn-carousel" type="submit" style="border-radius: 5px;"
                onclick="window.history.back()">Back to <?php echo e($active); ?></button>
            <button class="btn btn-on btn-carousel" type="submit" style="border-radius: 5px;"
                onclick="window.open('<?php echo e($albumDetail->external_urls->spotify); ?>', '_blank')">Listen at
                Spotify</button>
        </div>
    <?php endif; ?>
    <script>
        var currentAudio = null;
        var currentPlayBtn = null;

        function audioPlay(id) {
            var audio = document.getElementById(id);
            var PlayBtn = document.getElementById("button" + id);
            if (audio.paused) {
                if (currentAudio !== null && currentAudio !== audio) {
                    currentAudio.pause();
                    currentAudio.currentTime = 0;
                    document.getElementById(currentPlayBtn).innerHTML = "<i class='bi bi-play-circle-fill'>";
                }
                audio.play();
                currentAudio = audio;
                currentPlayBtn = "button" + id;
                PlayBtn.innerHTML = "<i class='bi bi-pause-circle-fill text-color'>";
            } else {
                audio.pause();
                audio.currentTime = 0;
                currentAudio = null;
                currentPlayBtn = null;
                PlayBtn.innerHTML = "<i class='bi bi-play-circle-fill'>";
            }
        };
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.' . $template, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web-Project\oraclesoundlab\oslwebsite\resources\views/releases_album.blade.php ENDPATH**/ ?>