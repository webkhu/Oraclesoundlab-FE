<div class="mb-4 row align-items-center">
    <div class="col">
        <h1><?php echo e($title); ?></h1>
    </div>
    <?php if($active === 'index' || $active === 'home'): ?>
        <div class="col text-end add-menu"><a href="<?php echo e(url('/events')); ?>">View more <i
                    class="bi bi-caret-right-fill"></i></a>
        </div>
    <?php endif; ?>
</div>
<?php if(!empty(@$events)): ?>
    <?php if($active != 'index' && $active != 'home' && $active != 'search'): ?>
        <div class="mb-3"><?php echo e($events->links('pagination::webkhu')); ?></div>
    <?php endif; ?>
    <div class="row g-4 cols-1 row-cols-sm-2 row-cols-md-4 row-cols-lg-4 row-cols-xl-6 row-cols-xxl-8">
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                list($d, $m, $Y) = explode('/', $event->date);
                if (strtotime($Y . '/' . $m . '/' . $d) > time()) {
                    $status = '';
                } else {
                    $status = 'Past Event';
                }
            ?>
            <div id="imgcontainer" class="col-xl-3" onClick="location.href='<?php echo e(url('/events/' . $event->slug)); ?>'">
                <div class="imgborder">
                    <div class="imggalbox">
                        <div class="bg-img-wrapper mb-4">
                            <div style="background-image:url(<?php echo e(url(env('API_LINK') . '/event/admin/' . $event->image)); ?>)"
                                class="bg-img d-flex">
                                <?php if($status): ?>
                                    <div class="img-status align-self-center"><?php echo e($status); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="img-setup">
                            <div class="bold text-glow mb-2"><?php echo e($event->title); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php /**PATH F:\Web-Project\oraclesoundlab\oslwebsite\resources\views/asset/events-catalog.blade.php ENDPATH**/ ?>