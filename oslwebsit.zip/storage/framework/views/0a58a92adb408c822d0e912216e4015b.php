

<?php $__env->startSection('content'); ?>
    <div class="mb-4 row align-items-center">
        <div class="col">
            <h1><?php echo e($title); ?></h1>
        </div>
        <?php if($active === 'index' || $active === 'home'): ?>
            <div class="col text-end add-menu"><a href="<?php echo e(url('/articles')); ?>">View more <i
                        class="bi bi-caret-right-fill"></i></a>
            </div>
        <?php endif; ?>
    </div>
    <?php if(!empty(@$articles)): ?>
        <?php if($active != 'index' && $active != 'home'): ?>
            <div class="mb-3"><?php echo e($articles->links('pagination::webkhu')); ?></div>
        <?php endif; ?>
        <div class="row g-4 cols-1 row-cols-sm-2 row-cols-md-4 row-cols-lg-4 row-cols-xl-6 row-cols-xxl-8">
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="imgcontainer" class="col-xl-3" onClick="location.href='<?php echo e(url('/article/' . $article->slug)); ?>'">
                    <div class="imgborder">
                        <div class="imggalbox">
                            <div class="bg-img-wrapper mb-4">
                                <div style="background-image:url(<?php echo e(url(env('API_LINK') . '/article/admin/' . $article->image)); ?>)"
                                    class="bg-img"></div>
                            </div>
                            <div class="img-setup">
                                <div class="bold text-glow mb-2"><?php echo e($article->title); ?></div>
                                <div class="text-justify"><?php echo e($article->short_desc); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.' . $template, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web-Project\oraclesoundlab\oslwebsite\resources\views/articles.blade.php ENDPATH**/ ?>