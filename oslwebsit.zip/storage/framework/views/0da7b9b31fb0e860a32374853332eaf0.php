<div class="mb-4 row align-items-center">
    <div class="col">
        <h1><?php echo e($title); ?></h1>
    </div>
    <?php if($active === 'index' || $active === 'home'): ?>
        <div class="col text-end add-menu"><a href="<?php echo e(url('/artists')); ?>">View more <i
                    class="bi bi-caret-right-fill"></i></a>
        </div>
    <?php endif; ?>
</div>
<?php if(!empty(@$artists)): ?>
    <?php if($active != 'index' && $active != 'home' && $active != 'search'): ?>
        <div class="mb-3"><?php echo e($artists->links('pagination::webkhu')); ?></div>
    <?php endif; ?>
    <div class="row g-4 cols-1 row-cols-sm-2 row-cols-md-3 row-cols-xl-6">
        <?php $__currentLoopData = $artists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="imgcontainer" class="col-xl-2" onClick="location.href='<?php echo e(url('/artists/' . $artist->slug)); ?>'">
                <div class="imgborder">
                    <div class="imggalbox text-glow">
                        <div class="bg-img-wrapper mb-4">
                            <div style="background-image:url(<?php echo e(url(env('API_LINK') . '/artists/admin/' . $artist->image)); ?>)"
                                class="bg-img"></div>
                        </div>
                        <div class="img-setup">
                            <div><?php echo e($artist->name); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php /**PATH F:\Web-Project\oraclesoundlab\oslwebsite\resources\views/asset/artist-catalog.blade.php ENDPATH**/ ?>