

<?php $__env->startSection('content'); ?>
    <?php if($datas === ''): ?>
        No data Founded
    <?php else: ?>
        <div style="width: 90%; margin: auto;">
            <img class="mb-5" src="<?php echo e(url(env('API_LINK') . '/article/admin/' . $datas->image)); ?>" alt="<?php echo e($datas->title); ?>"
                width="100%">
            <div class="mb-4">
                <h1 class="text-start"><?php echo e($datas->title); ?></h1>
            </div>
            <div class="artist-desc mb-5"><?php echo $datas->content; ?></div>
            <h3 class="mb-4">Photo Gallery</h3>
            <div class="row cols-1 row-cols-sm-2 row-cols-md-4 row-cols-lg-4">
                <?php if($items !== ''): ?>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div id="imgcontainer" class="col-lg-3 mb-4">
                            <div class="imgborder">
                                <div class="imggalbox">
                                    <div class="bg-img-wrapper mb-4">
                                        <div style="background-image:url(<?php echo e(url(env('API_LINK') . '/article/gallery/' . $item->image)); ?>)"
                                            class="bg-img"
                                            onClick="popup('<?php echo e(url(env('API_LINK') . '/article/gallery/' . $item->image)); ?>','<?php echo e($item->title); ?>');">
                                        </div>
                                    </div>
                                    <div class="img-setup">
                                        <div><?php echo e($item->title); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('asset.modalPopup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </div>
            <div class="d-flex mt-4 justify-content-start">
                <button class="btn btn-off btn-carousel" type="submit" style="border-radius: 5px;"
                    onclick="window.history.back()">Back to <?php echo e($active); ?></button>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.' . $template, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web-Project\oraclesoundlab\oslwebsite\resources\views/article.blade.php ENDPATH**/ ?>