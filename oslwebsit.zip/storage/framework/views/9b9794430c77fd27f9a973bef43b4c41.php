<?php if(@$partners != ''): ?>
    <div class="partners-area mt-4">
        <div id="partner" class="carousel slide col-12" data-bs-ride="carousel">
            <!-- The slideshow/carousel -->
            <div class="carousel-inner">
                <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $Image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        if ($key == 0) {
                            $act = 'active';
                        } else {
                            $act = '';
                        }
                    ?>
                    <a href="<?php echo e($Image->link); ?>">
                        <div class="carousel-item partner-item <?php echo e($act); ?>">
                            <img src="<?php echo e(env('API_LINK')); ?>/partner/<?php echo e($Image->image); ?>">
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH F:\Web-Project\oraclesoundlab\oslwebsite\resources\views/template/partner.blade.php ENDPATH**/ ?>