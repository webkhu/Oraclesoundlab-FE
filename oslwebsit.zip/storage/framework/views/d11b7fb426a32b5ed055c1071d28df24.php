

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4"><?php echo e($title); ?></h1>
    <?php if(!empty(@$page)): ?>
        <div>
            <?php echo $page->content; ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.' . $template, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web-Project\oraclesoundlab\oslwebsite\resources\views/additional.blade.php ENDPATH**/ ?>