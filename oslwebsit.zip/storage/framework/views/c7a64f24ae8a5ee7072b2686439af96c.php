

<?php $__env->startSection('content'); ?>
    <div class="row">
        
        <?php if(!empty(@$carousel)): ?>
            <div id="carousel" class="carousel slide col-12" data-bs-ride="carousel">
                <!-- The slideshow/carousel -->
                <div class="carousel-inner">
                    <?php $__currentLoopData = $carousel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $Image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            if ($key == 0) {
                                $act = 'active';
                            } else {
                                $act = '';
                            }
                        ?>

                        <div class="carousel-item <?php echo e($act); ?>"
                            style="background: url(<?php echo e(env('API_LINK')); ?>/carousel/<?php echo e($Image->image); ?>); background-position: center; background-repeat: no-repeat; background-size: cover;">
                            <div class="carousel-caption">
                                <h1><?php echo e($Image->title); ?></h1>
                                <div><?php echo e($Image->short_desc); ?></div>
                                <?php if($Image->link): ?>
                                    <div class="mt-4"><button type="button" class="btn btn-on btn-carousel"
                                            onclick="location.href='<?php echo e($Image->link); ?>'"><?php echo e($Image->link_title); ?></button>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- Indicators/dots -->
                <div class="carousel-indicators">
                    <?php $__currentLoopData = $carousel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $Image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            if ($key == 0) {
                                $act = 'active';
                            } else {
                                $act = '';
                            }
                        ?>
                        <button type="button" data-bs-target="#carousel" data-bs-slide-to=<?php echo e($key); ?>

                            class=<?php echo e($act); ?>></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- Left and right controls/icons -->
                
                
            </div>
        <?php endif; ?>
        
        <?php if(!empty(@$releases)): ?>
            <div class="col-12 mt-5 mb-3">
                <?php echo $__env->make('asset.releases-catalog', [
                    'title' => $page_title->get('releases'),
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php endif; ?>
        
        <?php if(!empty(@$artists)): ?>
            <div class="col-12 mt-5 mb-3">
                <?php echo $__env->make('asset.artist-catalog', [
                    'title' => $page_title->get('artists'),
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php endif; ?>
        
        <?php if(!empty(@$article)): ?>
            <div class="col-12 mt-5 mb-3">
                <?php echo $__env->make('asset.article-catalog', [
                    'title' => $page_title->get('article'),
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php endif; ?>
        
        <?php if(!empty(@$streaming)): ?>
            <div class="col-12 mt-5">
                <?php echo $__env->make('asset.streaming-catalog', [
                    'datas' => $streaming,
                    'title' => $page_title->get('streaming'),
                    'get_page' => 'streaming',
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.' . $template, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web-Project\oraclesoundlab\oslwebsite\resources\views/index.blade.php ENDPATH**/ ?>