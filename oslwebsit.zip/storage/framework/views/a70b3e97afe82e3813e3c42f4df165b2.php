

<?php $__env->startSection('content'); ?>
    <?php if($datas === ''): ?>
        No data Founded
    <?php else: ?>
        <div class="mb-5">
            <h1><?php echo e($datas->title); ?></h1>
        </div>
        <div class="artist-detail mb-5">
            <div class="artist-img album-img">
                <img src="<?php echo e(url(env('API_LINK') . '/event/admin/' . $datas->image)); ?>" alt="<?php echo e($datas->title); ?>"
                    width="100%">
            </div>
            <div id="details" class="artist-desc">
                <?php if($status): ?>
            <h2 class="mb-4" style="color:orangered"><?php echo e('# ' . $status); ?></h2>
            <?php endif; ?>
                <h4 class="mb-3"><strong>Perform date:</strong></h4>
                <div class="mb-4"><?php echo e($date); ?></div>
                <h4 class="mb-3"><strong>Event location:</strong></h4>
                <div class="mb-2"><?php echo e($datas->location); ?></div>
                <div class="mb-4 text-sm"><a href="javascript:popupMap('<?php echo e($datas->map); ?>')">Location map</a></div>
                <div><?php echo $datas->description; ?></div>
            </div>
        </div>

        <div class="d-flex mt-4 justify-content-start">
            <button class="btn btn-off btn-carousel" type="submit" style="border-radius: 5px;"
                onclick="window.history.back()">Back to <?php echo e($active); ?></button>
        </div>
    <?php endif; ?>
<?php echo $__env->make('asset.mapPopup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('asset.modalPopup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.' . $template, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web-Project\oraclesoundlab\oslwebsite\resources\views/event.blade.php ENDPATH**/ ?>