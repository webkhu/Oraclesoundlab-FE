

<?php $__env->startSection('content'); ?>
    <h1><?php echo e($title); ?></h1>
    <div class="row">
        
        <?php if(!empty(@$artists)): ?>
            <div class="col-12 mt-5 mb-3">
                <?php echo $__env->make('asset.artist-catalog', [
                    'title' => $page_title->get('artists'),
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php endif; ?>
        
        <?php if(!empty(@$events)): ?>
            <div class="col-12 mt-5 mb-3">
                <?php echo $__env->make('asset.events-catalog', [
                    'title' => $page_title->get('events'),
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php endif; ?>
        
        <?php if(!empty(@$articles)): ?>
            <div class="col-12 mt-5 mb-3">
                <?php echo $__env->make('asset.article-catalog', [
                    'title' => $page_title->get('article'),
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.' . $template, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web-Project\oraclesoundlab\oslwebsite\resources\views/Search.blade.php ENDPATH**/ ?>